package com.mcajayon.pet.models;

public interface Pet {
	String showAffection();
}