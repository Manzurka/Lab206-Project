package com.mcajayon.buttonclicker.models;

public class CountTest {
	public static void main(String[] args) {
		Count.addOne();
		System.out.println(Count.getButtonClicks());
	}
}